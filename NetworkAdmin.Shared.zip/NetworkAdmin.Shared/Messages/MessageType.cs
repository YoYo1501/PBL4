namespace NetworkAdmin.Shared.Messages;

public enum MessageType
{
    Hello = 1,
    HelloAck = 2,
    SystemStats = 3,
    NetworkInfo = 4,
    PingRequest = 5,
    PingResult = 6,
    ScanRequest = 7,
    ScanResult = 8,
    RemoteAdministrationCommand = 9,
    RemoteAdministrationResult = 10,
    RemoteAdministrationCancel = 11,
    ScreenShareRequest = 12,
    ScreenShareConsent = 13,
    ScreenShareStop = 14,
    ScreenChannelReady = 15,
    ScreenShareStart = 16,
    ControlRequest = 17,
    ControlConsent = 18,
    ControlStop = 19,
    ControlInputEvent = 20
}
