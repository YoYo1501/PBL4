using System.Net.Sockets;
using System.Text.Json;
using System.Collections.Concurrent;
using NetworkAdmin.Shared.Messages;
using NetworkAdmin.Shared.Protocol;
using NetworkAdmin.Shared.Models;

namespace NetworkAdmin.Server.Networking;

internal sealed class TcpHelloServer
{
    private readonly ServerOptions _options;
    private readonly ClientManager _clientManager;
    private readonly ServerCommandDispatcher _commandDispatcher;
    private readonly ConcurrentDictionary<TcpClient, byte> _activeClients = new();
    private readonly ScreenStreamingService? _screenStreaming;

    public TcpHelloServer(
        ServerOptions options,
        ClientManager clientManager,
        ServerCommandDispatcher commandDispatcher,
        ScreenStreamingService? screenStreaming = null)
    {
        _options = options;
        _clientManager = clientManager;
        _commandDispatcher = commandDispatcher;
        _screenStreaming = screenStreaming;
    }

    private volatile bool _isListening;
    public bool IsListening => _isListening;

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        using var connections = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var listener = new TcpListener(_options.Host, _options.Port);
        var handlers = new List<Task>();

        try
        {
            listener.Start();
            _isListening = true;
            Console.WriteLine($"Listening on {_options.Host}:{_options.Port}");
            while (!cancellationToken.IsCancellationRequested)
            {
                var client = await listener.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);
                _activeClients.TryAdd(client, 0);
                if (cancellationToken.IsCancellationRequested)
                {
                    CloseClient(client);
                    continue;
                }

                handlers.RemoveAll(t => t.IsCompleted);
                handlers.Add(ObserveClientHandlerAsync(client, connections.Token));
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
        }
        finally
        {
            _isListening = false;
            listener.Stop();
            await connections.CancelAsync();
            foreach (var client in _activeClients.Keys)
            {
                CloseClient(client);
            }

            await Task.WhenAll(handlers).ConfigureAwait(false);
        }
    }

    private async Task ObserveClientHandlerAsync(TcpClient client, CancellationToken cancellationToken)
    {
        var remoteEndPoint = GetRemoteEndPoint(client);
        try
        {
            await HandleClientAsync(client, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Unhandled client handler error from {remoteEndPoint}: {ex.Message}");
        }
        finally
        {
            CloseClient(client);
        }
    }

    private void CloseClient(TcpClient client)
    {
        _activeClients.TryRemove(client, out _);
        try { client.Dispose(); }
        catch (Exception ex) { Console.WriteLine($"Client socket cleanup failed: {ex.Message}"); }
    }

    private static string GetRemoteEndPoint(TcpClient client)
    {
        try { return client.Client.RemoteEndPoint?.ToString() ?? "unknown"; }
        catch (ObjectDisposedException) { return "unknown"; }
        catch (SocketException) { return "unknown"; }
    }

    private async Task HandleClientAsync(TcpClient client, CancellationToken serverCancellationToken)
    {
        var remoteEndPoint = GetRemoteEndPoint(client);
        var sessionId = string.Empty;

        try
        {
            using (client)
            await using (var networkStream = client.GetStream())
            {
                JsonLineProtocol.EnableKeepAlive(client);
                using var helloTimeout = CancellationTokenSource.CreateLinkedTokenSource(serverCancellationToken);
                helloTimeout.CancelAfter(TimeSpan.FromSeconds(10));
                var envelope = await JsonLineProtocol.ReceiveAsync(networkStream, cancellationToken: helloTimeout.Token)
                    .ConfigureAwait(false);

                if (envelope is null)
                {
                    Console.WriteLine($"Client disconnected before hello: {remoteEndPoint}");
                    return;
                }

                if (envelope.Type != MessageType.Hello)
                {
                    Console.WriteLine($"Invalid first message from {remoteEndPoint}: {envelope.Type}");
                    return;
                }

                var hello = JsonLineProtocol.GetPayload<HelloMessage>(envelope);
                if (hello is null || string.IsNullOrWhiteSpace(hello.ClientId) || string.IsNullOrWhiteSpace(hello.ClientName))
                {
                    Console.WriteLine($"Invalid hello from {remoteEndPoint}");
                    return;
                }

                sessionId = Guid.NewGuid().ToString("N");
                var session = _clientManager.Register(hello.ClientId, hello.ClientName, sessionId, networkStream,
                    out var replacedSession, client.Client,
                    (client.Client.RemoteEndPoint as System.Net.IPEndPoint)?.Address.ToString() ?? string.Empty);
                if (replacedSession is not null)
                {
                    _commandDispatcher.FailPendingForSession(replacedSession.SessionId,
                        new IOException($"Client session replaced: {replacedSession.SessionId}"));
                    if (_screenStreaming is not null)
                        await _screenStreaming.StopForSessionAsync(replacedSession.SessionId, "Client session was replaced.")
                            .ConfigureAwait(false);
                }
                Console.WriteLine("Client connected");
                Console.WriteLine($"ClientId: {session.ClientId}");
                Console.WriteLine($"ClientName: {session.ClientName}");
                Console.WriteLine($"SessionId: {session.SessionId}");

                await _clientManager.SendAsync(
                    sessionId,
                    MessageType.HelloAck,
                    envelope.RequestId,
                    new HelloAckMessage
                    {
                        Accepted = true,
                        SessionId = sessionId,
                        Message = "Hello accepted"
                    },
                    serverCancellationToken).ConfigureAwait(false);

                session.IsReady = true;

                while (!serverCancellationToken.IsCancellationRequested)
                {
                    var next = await JsonLineProtocol.ReceiveAsync(networkStream, cancellationToken: serverCancellationToken)
                        .ConfigureAwait(false);

                    if (next is null)
                    {
                        Console.WriteLine($"Client disconnected: {sessionId}");
                        return;
                    }

                    if (next.Type == MessageType.SystemStats)
                    {
                        HandleSystemStats(sessionId, next);
                        continue;
                    }

                    if (next.Type == MessageType.NetworkInfo)
                    {
                        HandleNetworkInfo(sessionId, next);
                        continue;
                    }

                    if (next.Type == MessageType.PingResult)
                    {
                        HandlePingResult(sessionId, next);
                        continue;
                    }

                    if (next.Type == MessageType.ScanResult)
                    {
                        HandleScanResult(sessionId, next);
                        continue;
                    }

                    if (next.Type == MessageType.RemoteAdministrationResult)
                    {
                        HandleRemoteAdministrationResult(sessionId, next);
                        continue;
                    }

                    if (next.Type is MessageType.ScreenShareConsent or MessageType.ScreenShareStop)
                    {
                        if (_screenStreaming is not null)
                            await _screenStreaming.HandleControlMessageAsync(session, next).ConfigureAwait(false);
                        continue;
                    }

                    Console.WriteLine($"Ignoring unsupported message from {sessionId}: {next.Type}");
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed JSON from {remoteEndPoint}: {ex.Message}");
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Connection IO error from {remoteEndPoint}: {ex.Message}");
        }
        catch (SocketException ex)
        {
            Console.WriteLine($"Socket error from {remoteEndPoint}: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Client handler error from {remoteEndPoint}: {ex.Message}");
        }
        finally
        {
            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                if (_screenStreaming is not null)
                    await _screenStreaming.StopForSessionAsync(sessionId, "Client disconnected or session ended.", notifyClient: false)
                        .ConfigureAwait(false);
                _clientManager.Remove(sessionId);
                _commandDispatcher.FailPendingForSession(sessionId, new IOException($"Client disconnected: {sessionId}"));
            }
        }
    }

    private void HandleSystemStats(string sessionId, MessageEnvelope envelope)
    {
        try
        {
            var stats = JsonLineProtocol.GetPayload<SystemStats>(envelope);
            if (stats is null || !IsValid(stats))
            {
                Console.WriteLine($"Malformed SystemStats from {sessionId}");
                return;
            }

            if (!_clientManager.UpdateSystemStats(sessionId, stats, out var session) || session is null)
            {
                Console.WriteLine($"SystemStats from unknown session: {sessionId}");
                return;
            }

            // Telemetry is high-frequency; keep it out of the interactive console.
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed SystemStats from {sessionId}: {ex.Message}");
        }
    }

    private void HandleNetworkInfo(string sessionId, MessageEnvelope envelope)
    {
        try
        {
            var networkInfo = JsonLineProtocol.GetPayload<ClientNetworkInfo>(envelope);
            if (networkInfo is null || string.IsNullOrWhiteSpace(networkInfo.Hostname))
            {
                Console.WriteLine($"Malformed NetworkInfo from {sessionId}");
                return;
            }

            networkInfo.Interfaces ??= new List<NetworkInterfaceInfo>();
            networkInfo.Interfaces = networkInfo.Interfaces.Where(i => i is not null).ToList();

            if (!_clientManager.UpdateNetworkInfo(sessionId, networkInfo, out var session) || session is null)
            {
                Console.WriteLine($"NetworkInfo from unknown session: {sessionId}");
                return;
            }

            Console.WriteLine($"[{session.ClientName}] NetworkInfo");
            foreach (var item in networkInfo.Interfaces)
            {
                Console.WriteLine($"IPv4: {Display(item.IpAddress)}");
                Console.WriteLine($"MAC: {Display(item.MacAddress)}");
                Console.WriteLine($"Gateway: {Display(item.Gateway)}");
                Console.WriteLine($"Interface: {Display(item.Name)}");
                Console.WriteLine($"Description: {Display(item.Description)}");
            }
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed NetworkInfo from {sessionId}: {ex.Message}");
        }
    }

    private void HandlePingResult(string sessionId, MessageEnvelope envelope)
    {
        try
        {
            var result = JsonLineProtocol.GetPayload<PingResult>(envelope);
            if (result is null)
            {
                Console.WriteLine($"Malformed PingResult from {sessionId}");
                return;
            }

            if (!_clientManager.TryGet(sessionId, out var session) || session is null)
            {
                Console.WriteLine($"PingResult from unknown session: {sessionId}");
                return;
            }

            if (!_commandDispatcher.CompletePing(sessionId, envelope.RequestId, result))
            {
                Console.WriteLine($"Unexpected PingResult from {sessionId}: {envelope.RequestId}");
                return;
            }

            Console.WriteLine("Ping result");
            Console.WriteLine($"Client: {session.ClientName}");
            Console.WriteLine($"Target: {result.Host}");
            Console.WriteLine($"Success: {result.Success}");
            Console.WriteLine($"RoundTripTime: {result.RoundtripTimeMs} ms");
            Console.WriteLine($"Status: {result.StatusMessage}");
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed PingResult from {sessionId}: {ex.Message}");
        }
    }

    private void HandleScanResult(string sessionId, MessageEnvelope envelope)
    {
        try
        {
            var result = JsonLineProtocol.GetPayload<ScanResultMessage>(envelope);
            if (result is null)
            {
                Console.WriteLine($"Malformed ScanResult from {sessionId}");
                return;
            }

            result.Devices ??= new();
            result.Devices = result.Devices.Where(d => d is not null).ToList();
            if (!_clientManager.TryGet(sessionId, out var session) || session is null)
            {
                Console.WriteLine($"ScanResult from unknown session: {sessionId}");
                return;
            }

            if (!_commandDispatcher.CompleteScan(sessionId, envelope.RequestId, result))
            {
                Console.WriteLine($"Unexpected ScanResult from {sessionId}: {envelope.RequestId}");
                return;
            }

            _clientManager.UpdateScanResult(sessionId, result, out _);
            Console.WriteLine("Scan completed");
            Console.WriteLine($"Client: {session.ClientName}");
            Console.WriteLine($"Devices found: {result.Devices.Count}");
            foreach (var device in result.Devices.Take(20))
            {
                Console.WriteLine(device.IpAddress);
                Console.WriteLine($"MAC: {Display(device.MacAddress)}");
                Console.WriteLine($"Status: {(device.IsOnline ? "Online" : "Offline")}");
            }

            if (!result.Success && !string.IsNullOrWhiteSpace(result.ErrorMessage))
            {
                Console.WriteLine($"Scan error: {result.ErrorMessage}");
            }
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed ScanResult from {sessionId}: {ex.Message}");
        }
    }

    private void HandleRemoteAdministrationResult(string sessionId, MessageEnvelope envelope)
    {
        try
        {
            var result = JsonLineProtocol.GetPayload<RemoteAdministrationResultMessage>(envelope);
            if (result is null)
            {
                Console.WriteLine($"Malformed remote administration result from {sessionId}");
                return;
            }

            if (!_commandDispatcher.CompleteRemoteAdministrationCommand(sessionId, envelope.RequestId, result))
            {
                Console.WriteLine($"Unexpected remote administration result from {sessionId}: {envelope.RequestId}");
                return;
            }

            Console.WriteLine($"Remote command {result.Command}: {result.Status}");
        }
        catch (JsonException ex)
        {
            Console.WriteLine($"Malformed remote administration result from {sessionId}: {ex.Message}");
        }
    }

    private static bool IsValid(SystemStats stats)
    {
        return !float.IsNaN(stats.CpuUsagePercent)
            && !float.IsInfinity(stats.CpuUsagePercent)
            && !float.IsNaN(stats.RamUsagePercent)
            && !float.IsInfinity(stats.RamUsagePercent)
            && stats.CpuUsagePercent >= 0
            && stats.RamUsagePercent >= 0;
    }

    private static string Display(string? value) =>
        string.IsNullOrWhiteSpace(value) ? "-" : value;
}
